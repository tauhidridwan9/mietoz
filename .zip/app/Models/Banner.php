<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    use HasFactory;

    protected $fillable = ['path'];

    // Jika Anda ingin menambahkan relasi atau metode tambahan, Anda dapat melakukannya di sini.
}
