<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('registsucces')): ?>
    <?php $__env->startSection('scripts'); ?>
    <script>
        Swal.fire({
            title: 'Selamat Datang',
            text: 'Silahkan mulai pengalaman belanja yang menarik',
            icon: 'success',
            showCancelButton: false,
            confirmButtonText: 'OK'
        });
    </script>
    <?php $__env->stopSection(); ?>
    <?php endif; ?>
    <!-- Banner Section -->
    <?php
    $banners = App\Models\Banner::latest()->take(5)->get();
    ?>

    <?php if($banners->count() > 0): ?>
    <div id="bannerCarousel" class="carousel slide mb-4" data-bs-ride="carousel" data-bs-interval="3000">
        <div class="carousel-inner">
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                <img src="<?php echo e(asset('storage/' . $banner->path)); ?>" class="d-block w-100"
                    style="object-fit: cover; height: 300px; object-position: center top;" alt="Banner">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#bannerCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#bannerCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <?php endif; ?>

    <div class="mb-4">
        <form action="<?php echo e(route('products.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="Cari produk..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-4">
                <select name="price" class="form-control">
                    <option value="">Filter berdasarkan harga</option>
                    <option value="low_to_high" <?php echo e(request('price') == 'low_to_high' ? 'selected' : ''); ?>>Harga Rendah ke Tinggi</option>
                    <option value="high_to_low" <?php echo e(request('price') == 'high_to_low' ? 'selected' : ''); ?>>Harga Tinggi ke Rendah</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="category" class="form-control">
                    <option value="">Filter berdasarkan kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-success w-100">Cari</button>
            </div>
        </form>
    </div>

    <h1>Produk Terbaru</h1>

    <?php if(isset($message)): ?>
    <div class="alert alert-info">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-3">
            <div class="card">
    <a href="<?php echo e(route('products.show', $product->id)); ?>" style="text-decoration: none; color: inherit;">
        <?php if($product->image): ?>
        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" style="width: 100%; height: 200px; object-fit: cover;" class="card-img-top" alt="<?php echo e($product->name); ?>">
        <?php endif; ?>
        <div class="card-body">
            <h5 class="fs-4 text-primary"><?php echo e($product->name); ?></h5>
            <p class="card-text text-secondary"><?php echo e($product->description); ?></p>
            <p class="card-text text-danger">Stok: <?php echo e($product->stock); ?> <?php echo e($product->stock > 1 ? 'items' : 'item'); ?></p>
            <p class="card-text text-primary fs-4">Rp <?php echo e(number_format($product->price, 2, ',', '.')); ?></p>
        </div>
    </a>
    <?php if(auth()->guard()->check()): ?>
    <?php if($product->stock > 0): ?>
    <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Add to Cart <i class="fas fa-shopping-cart"></i></button>
    </form>
    <?php else: ?>
    <button class="btn btn-secondary" disabled>Out of Stock</button>
    <?php endif; ?>
    <?php else: ?>
    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary" id="login-button">Add to Cart</a>
    <?php endif; ?>
</div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mendapatkan elemen tombol "Tambahkan ke Keranjang"
        var addToCartButtons = document.querySelectorAll('#login-button');

        addToCartButtons.forEach(function(button) {
            button.addEventListener('click', function(event) {
                event.preventDefault(); // Mencegah pengiriman formulir
                Swal.fire({
                    title: 'Anda Belum Login!',
                    text: 'Silakan login atau daftar untuk menambahkan produk ke keranjang.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Login',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "<?php echo e(route('login')); ?>";
                    }
                });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/home.blade.php ENDPATH**/ ?>