


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <?php if($product->image): ?>
            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-fluid" alt="<?php echo e($product->name); ?>">
            <?php else: ?>
            <img src="https://via.placeholder.com/500" class="img-fluid" alt="<?php echo e($product->name); ?>">
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <h2><?php echo e($product->name); ?></h2>
            <p><?php echo e($product->description); ?></p>
            <p><strong>Harga:</strong> Rp <?php echo e(number_format($product->price, 2, ',', '.')); ?></p>
            <p><strong>Stok:</strong> <?php echo e($product->stock); ?> <?php echo e($product->stock > 1 ? 'items' : 'item'); ?></p>

            <?php if(auth()->guard()->check()): ?>
            <?php if($product->stock > 0): ?>
            <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Add to Cart <i class="fas fa-shopping-cart"></i></button>
            </form>
            <?php else: ?>
            <button class="btn btn-secondary" disabled>Out of Stock</button>
            <?php endif; ?>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary" id="login-button">Add to Cart</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/products/detail.blade.php ENDPATH**/ ?>