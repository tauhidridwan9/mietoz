

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Daftar Produk</h1>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3"><i class="fa-solid fa-plus"></i>Tambah Produk</a>

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-3">
            <div class="product">
                <?php if($product->image): ?>
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" style=" width: 100%;
            height: 200px;
            /* fixed height for image */
            object-fit: cover;" class="thumbnail" alt="<?php echo e($product->name); ?>">
                <?php endif; ?>
                <div class="body-product">
                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                    <p class="card-text"><?php echo e($product->description); ?></p>
                    <p>Stock: <?php echo e($product->stock > 0 ? $product->stock : 'Out of stock'); ?></p>
                    <p class="card-text">Rp <?php echo e(number_format($product->price, 2, ',', '.')); ?></p>
                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning"><i class="fa-solid fa-edit"></i>Edit</a>
                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i>Hapus</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.owner.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/products/index.blade.php ENDPATH**/ ?>