<!-- resources/views/banners/index.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Kelola Banner</h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <a href="<?php echo e(route('banner.create')); ?>" class="btn btn-primary mb-3">Tambah Banner</a>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Banner</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img src="<?php echo e(asset('storage/' . $banner->path)); ?>" alt="Banner" width="200">
                    </td>
                    <td>
                        <a href="<?php echo e(route('banner.edit', $banner->id)); ?>" class="btn btn-warning">Edit</a>

                        <form action="<?php echo e(route('banner.destroy', $banner->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus banner ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.owner.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/banners/index.blade.php ENDPATH**/ ?>