

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Produk</h1>

    <!-- Display validation errors -->
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Product Edit Form -->
    <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group mb-3">
            <label for="name">Nama Produk</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $product->name)); ?>" required>
        </div>

        <div class="form-group mb-3">
            <label for="description">Deskripsi</label>
            <textarea name="description" id="description" class="form-control" rows="4" required><?php echo e(old('description', $product->description)); ?></textarea>
        </div>

        <div class="form-group mb-3">
            <label for="price">Harga</label>
            <input type="number" name="price" id="price" class="form-control" value="<?php echo e(old('price', $product->price)); ?>" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="stock">Stock</label>
            <input type="number" name="stock" class="form-control" id="stock" value="<?php echo e(old('stock', $product->stock)); ?>">
        </div>


        <div class="form-group mb-3">
            <label for="category">Kategori</label>
            <select name="category_id" id="category" class="form-control" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == old('category_id', $product->category_id) ? 'selected' : ''); ?>>
                    <?php echo e($category->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="image">Gambar Produk</label>
            <?php if($product->image): ?>
            <div class="mb-2">
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" width="100">
            </div>
            <?php endif; ?>
            <input type="file" name="image" id="image" class="form-control">
        </div>

        <div class="form-group mb-3">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.owner.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/products/edit.blade.php ENDPATH**/ ?>