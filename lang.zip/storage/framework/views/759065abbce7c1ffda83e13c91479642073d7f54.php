

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Profile</h1>

    <form method="POST" action="<?php echo e(route('profile.update', $user->id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>


        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
        </div>

        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>">
        </div>

        <div class="form-group">
            <label for="telephone">Telephone</label>
            <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo e($user->telephone); ?>">
        </div>

        <div class="form-group">
            <label for="alamat">Alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($user->alamat); ?>">
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
        </div>

        <div class="form-group">
            <label for="profile_picture">Profile Picture</label>
            <input type="file" class="form-control" id="profile_picture" name="profile_pictures">
            <?php if($user->profile_picture): ?>
            <img src="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" alt="Profile Picture" width="100">
            <?php endif; ?>
        </div>

        <div class="form-group mb-2">
            <label for="bio">Bio</label>
            <textarea class="form-control" id="bio" name="bio"><?php echo e($user->bio); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/profile/edit.blade.php ENDPATH**/ ?>