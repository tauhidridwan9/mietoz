

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Manage Cashier</h1>

    <!-- Button to add new admin -->
    <a href="<?php echo e(route('owner.admins.create')); ?>" class="btn btn-success mb-4"><i class="fa-solid fa-plus"></i>Add New Cashier</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($admin->id); ?></td>
                <td><?php echo e($admin->name); ?></td>
                <td><?php echo e($admin->email); ?></td>
                <td>
                    <!-- Edit button -->
                    <a href="<?php echo e(route('owner.admins.edit', $admin->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-edit"></i>Edit</a>

                    <!-- Delete button with form for CSRF protection -->
                    <form action="<?php echo e(route('owner.admins.destroy', $admin->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this admin?');"><i class="fa-solid fa-trash"></i>Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.owner.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/owner/admins/index.blade.php ENDPATH**/ ?>