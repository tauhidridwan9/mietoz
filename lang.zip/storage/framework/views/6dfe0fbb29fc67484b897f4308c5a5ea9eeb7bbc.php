<!DOCTYPE html>
<html>
<head>
    <title>Pembayaran Cash</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            width: 80%;
            margin: 40px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th, .table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .table th {
            background-color: #f0f0f0;
        }

        .total {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Pembayaran Cash</h1>

        <p>Silakan melakukan pembayaran cash ke kasir.</p>

        <table class="table">
            <thead>
                <tr>
                    <th>Nomor Pesanan</th>
                    <th>Tanggal Pesanan</th>
                    <th>Nama</th>
                    <th>Menu Pesanan</th>
                    <th>Kuantitas</th>
                    <th>Total Pembayaran</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->created_at); ?></td>
                    <td><?php echo e($order->user->name); ?></td>
                    <td><?php echo e($item->product_name); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td>Rp. <?php echo e(number_format($item->quantity * $item->price, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <p>Silakan tunjukkan PDF ini ke kasir untuk menukarkannya dengan barang pesanan.</p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/orders/resi.blade.php ENDPATH**/ ?>