

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Order Sukses</h1>
    <p>Pesanan Anda dengan ID <?php echo e($order->id); ?> telah berhasil diproses.</p>

    <?php if($order->orderItems && $order->orderItems->isNotEmpty()): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Produk</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Total</th>
                <th>
                Status
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product_name); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td><?php echo e($item->price); ?></td>
                <td><?php echo e($item->quantity * $item->price); ?></td>
                <td><?php echo e($item->order->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>Detail pesanan tidak tersedia.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/orders/success.blade.php ENDPATH**/ ?>