

<?php $__env->startSection('content'); ?>
 
<div class="container">
    <h1>Menu Kasir</h1>
     <form action="<?php echo e(route('cash.payment.process', $order->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    

        <div class="form-group mb-3">
            <label for="name">Nomor Order</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $order->id)); ?>" required>
        </div>

        <div class="form-group mb-3">
            <label for="tagihan">Tagihan</label>
            <input name="tagihan" id="tagihan" class="form-control" rows="4" required value="<?php echo e(old('tagihan', $order->total_amount)); ?>" readonly>
        </div>

        <div class="form-group mb-3">
            <label for="nominal">Nominal Uang</label>
            <input name="nominal" id="nominal" class="form-control" rows="4" required></input>
        </div>
        <?php if(session('success')): ?>
          
         <?php endif; ?>


        <div class="form-group mb-3">
    <?php if(!session('success')): ?>
        <button type="submit" class="btn btn-primary">Input</button>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <a href="<?php echo e(route('orders.manage.process')); ?>" class="btn btn-secondary">Kembali</a>
    <?php endif; ?>
</div>
         
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/orders/cash-payment.blade.php ENDPATH**/ ?>