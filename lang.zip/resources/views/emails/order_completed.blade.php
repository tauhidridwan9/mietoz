<!DOCTYPE html>
<html>

<head>
    <title>Order Completed</title>
</head>

<body>
    <h1>Order Completed</h1>
    <p>Your order #{{ $order->id }} has been successfully completed.</p>
    <p>Thank you for shopping with us!</p>
</body>

</html>