

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Checkout</h1>
 <?php if($cart->isEmpty()): ?>
        <div class="alert alert-warning text-center">
            Keranjang kosong
        </div>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Produk</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($details['name']); ?></td>
                <td><?php echo e($details['quantity']); ?></td>
                <td>Rp <?php echo e(number_format($details['price'], 2, ',', '.')); ?></td>
                <td>Rp <?php echo e(number_format($details['price'] * $details['quantity'], 2, ',', '.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="container d-flex align-items-center justify-content-center p-2">
        <button id="pay-button" class="btn btn-primary">Pay Via Online</button>
        <a class="btn btn-warning text-decoration-none rounded-2 text-light btn-primary p-2" href="<?php echo e(route('cash.payment', $order->id)); ?>">Bayar Tunai</a>
    </div>
    <?php endif; ?>

    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <!-- Include Midtrans Snap.js -->
    <script type="text/javascript"
        src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(env('MIDTRANS_CLIENT_KEY')); ?>"></script>
    <script>
        document.getElementById('pay-button').addEventListener('click', function() {
            fetch('<?php echo e(route('payment.pay')); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({
                            order_id: '<?php echo e($order->id); ?>',
                            cart: <?php echo json_encode($cart, 15, 512) ?> // Pass data cart ke JavaScript
                        })
                    })
                .then(response => response.json())
                .then(data => {
                    if (data.snapToken) {
                        snap.pay(data.snapToken, {
                            onSuccess: function(result) {
                                window.location.href = '<?php echo e(route("payment.finish")); ?>?order_id=<?php echo e($order->id); ?>';
                            },
                            onPending: function(result) {
                                window.location.href = '<?php echo e(route("orders.pending", $order->id)); ?>';
                            },
                            onError: function(result) {
                                window.location.href = '<?php echo e(route("orders.failed", $order->id)); ?>';
                            }
                        });
                    } else {
                        alert('Gagal memproses pembayaran. Silakan coba lagi.');
                    }
                })
                .catch(error => console.error('Error:', error));
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/checkout/index.blade.php ENDPATH**/ ?>