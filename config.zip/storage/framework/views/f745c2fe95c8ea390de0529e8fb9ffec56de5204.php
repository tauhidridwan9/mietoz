

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="mb-4">Dashboard Kasir</h1>

    <div class="row mb-3">
        <div class="col-12">
            <?php if($notifications->isNotEmpty()): ?>
            <div class="alert alert-info">
                <h4>Notifications</h4>
                <form action="<?php echo e(route('admin.notifications.clearAll')); ?>" method="POST" class="mb-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Clear All</button>
                </form>
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-warning d-flex justify-content-between align-items-center">
                   
                        <div class="col-10"><?php echo e($notification->data['message']); ?></div>
                        <div class="col-1 m-sm-2"> <?php if(!$notification->read_at): ?>
                            <form action="<?php echo e(route('admin.notifications.read', $notification->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-sm btn-success">Mark as Read</button>
                            </form>
                            <?php endif; ?>

                            <?php if(isset($notification->data['product_id'])): ?>
                            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-sm btn-primary">View Product</a>
                            <?php endif; ?>
                        </div>
                        <div class="col-1">
                            <form action="<?php echo e(route('admin.notifications.destroy', $notification->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </form>
                        </div>


                  

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
            <p>No notifications at this time.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-md-4 mb-3">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title">Jumlah Produk</h5>
                </div>
                <div class="card-body text-center">
                    <p class="card-text fs-2"><?php echo e($productCount); ?> produk</p>
                    <i class="fas fa-box fa-2x"></i>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="card shadow">
                <div class="card-header bg-info text-white">
                    <h5 class="card-title">Jumlah Pesanan</h5>
                </div>
                <div class="card-body text-center">
                    <p class="card- fs-2"><?php echo e($orderCount); ?> pesanan</p>
                    <i class="fas fa-shopping-cart fa-2x"></i>
                    <a href="<?php echo e(route('orders.manage')); ?>" class="btn btn-primary mt-2">Kelola Pesanan</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card shadow">
                <div class="card-header bg-info text-white">
                    <h5 class="card-title">Pesanan Diproses</h5>
                </div>
                <div class="card-body text-center">
                    <p class="card- fs-2"><?php echo e($countProcessing); ?> pesanan sedang diproses</p>
                    <i class="fas fa-shopping-cart fa-2x"></i>
                    <a href="<?php echo e(route('orders.manage.process')); ?>" class="btn btn-primary mt-2">Kelola Pesanan</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="card shadow">
                <div class="card-header bg-success text-white">
                    <h5 class="card-title">Jumlah Customer</h5>
                </div>
                <div class="card-body text-center">
                    <p class="card-text fs-2"><?php echo e($customerCount); ?> customer</p>
                    <i class="fas fa-users fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>