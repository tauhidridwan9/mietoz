

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Kelola Pesanan</h1>
    <?php if($orders->isNotEmpty()): ?>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-3">
        <div class="card-header">
            <h5 class="card-title">Pesanan dari: <?php echo e($order->user->name); ?></h5> <!-- Menampilkan nama user -->
        </div>
        <div class="card-body">
            <h5 class="card-title">Rincian Pesanan #<?php echo e($order->id); ?></h5>
            <ul>
                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <strong>Produk:</strong> <?php echo e($item->product_name); ?> <br>
                    <strong>Quantity:</strong> <?php echo e($item->quantity); ?> <br>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <p><strong>Alamat:</strong> <?php echo e($order->user->alamat); ?></p>
            <p><strong>Status:</strong> <?php echo e($order->status); ?></p>

            <?php if($order->status == 'paid' || $order->status == 'cash'): ?>
            <form action="<?php echo e(route('orders.accept', $order->id)); ?>" method="POST" class="mt-3">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Terima Pesanan</button>
            </form>
            <?php endif; ?>

            <?php if($order->status == 'processing'): ?>
            <form action="<?php echo e(route('orders.delivered', $order->id)); ?>" method="POST" class="mt-3">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success">Kirim Pesanan</button>
            </form>
            <?php endif; ?>

            <!-- Button to view PDF -->
            <?php if($order->pdf_link): ?>
            <a href="<?php echo e(route('orders.pdf', $order->id)); ?>" class="mt-2 btn btn-secondary">Lihat PDF</a>

            <?php endif; ?>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <p>Detail pesanan tidak tersedia.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/orders/manage.blade.php ENDPATH**/ ?>