<!-- resources/views/cart/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Keranjang Belanja</h1>
    <?php if(session('error')): ?>
    <?php $__env->startSection('scripts'); ?>
    <script>

                        Swal.fire({
                            title: 'Stock Tidak Cukup',
                            text: 'Kuantitas anda melebihi stock yang kami punya.',
                            icon: 'error',
                            showCancelButton: false,
                            confirmButtonText: 'OK'
                        });
    </script>
    <?php $__env->stopSection(); ?>
    <?php endif; ?>

    <?php if($items->count()): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Produk</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Total</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($item->product): ?>
                    <img src="<?php echo e(asset('storage/' . $item->product->image)); ?>" width="50" alt="<?php echo e($item->product->name); ?>">
                    <p><?php echo e($item->product->name); ?></p>
                    <?php else: ?>
                    <p>Produk tidak ditemukan.</p>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="<?php echo e(route('cart.update', $item->id)); ?>" method="POST" style="display: flex; align-items: center;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" class="form-control" style="width: 80px;">
                        <button type="submit" class="btn btn-success ml-2">Update</button>
                    </form>
                </td>
                <td>
                    Rp <?php echo e(number_format($item->price, 2, ',', '.')); ?>

                </td>
                <td>
                    Rp <?php echo e(number_format($item->price * $item->quantity, 2, ',', '.')); ?>

                </td>
                <td>
                    <form action="<?php echo e(route('cart.remove', $item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-end">
        <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-success">Checkout</a>
    </div>
    <?php else: ?>
    <p>Keranjang Anda kosong.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/cart/index.blade.php ENDPATH**/ ?>