

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Laporan Pendapatan</h1>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Banyaknya Produk Terjual</th>
                        <th>Pendapatan Produk</th>
                        <th>Stok Produk</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reportItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product_name); ?></td>
                            <td><?php echo e($item->total_quantity); ?> unit</td>
                            <td>Rp <?php echo e(number_format($item->total_revenue, 2)); ?></td>
                            <td>
                                <?php $__currentLoopData = $productStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($product->name == $item->product_name): ?>
                                        <?php echo e($product->stock); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.owner.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/owner/reports/index.blade.php ENDPATH**/ ?>