

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Pembayaran Cash</h1>

    <p>Tunjukan struk pembayaran ke kasir.</p>

    <table class="table">
        <thead>
            <tr>
                <th>Nomor Pesanan</th>
                <th>Tanggal Pesanan</th>
                <th>Nama</th>
                <th>Menu Pesanan</th>
                <th>Kuantitas</th>
                <th>Total Pembayaran</th>
            </tr>
        </thead>
        <tbody>
            <?php if($order->orderItems->isEmpty()): ?>
                <tr>
                    <td colspan="6" class="text-center">Keranjang kosong</td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td><?php echo e($order->user->name); ?></td>
                        <td><?php echo e($item->product_name); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td>Rp. <?php echo e(number_format($item->quantity * $item->price, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>

    <button type="button" class="btn btn-secondary" onclick="window.location.href='<?php echo e(route('cash.payment.pdf', $order->id)); ?>'">Download Struk</button>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/checkout/cash.blade.php ENDPATH**/ ?>