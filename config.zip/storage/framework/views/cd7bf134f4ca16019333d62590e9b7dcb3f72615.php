

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Notifikasi</h1>
    <form action="<?php echo e(route('owner.notifications.clearAll')); ?>" method="POST" class="mb-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Clear All</button>
                </form>
    <?php if($notifications->count()): ?>
    <ul class="list-group ">
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item mb-3">
            <?php echo e($notification->data['message']); ?>

            <div class="col"><small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small></div>
            

            <?php if(isset($notification->data['confirmation_url']) && $notification->data['order_status'] === 'delivered'): ?>
            <a href="<?php echo e($notification->data['confirmation_url']); ?>" class="mt-1 btn btn-success btn-sm">
                Konfirmasi Kedatangan
            </a>
            <?php endif; ?>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php else: ?>
    <p>Anda tidak memiliki notifikasi baru.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.owner.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mietoz\mietoz\resources\views/notifications/owner-notif.blade.php ENDPATH**/ ?>